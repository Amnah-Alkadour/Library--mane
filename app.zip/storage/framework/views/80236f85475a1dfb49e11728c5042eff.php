<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('message.book')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Button trigger modal for adding book -->
            <button type="button" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#addBookModal">
                <?php echo e(__('message.add')); ?>

            </button>

            <!-- Modal for adding book -->
            <div class="modal fade" id="addBookModal" tabindex="-1" aria-labelledby="addBookModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addBookModalLabel"><?php echo e(__('message.addform')); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('books.store')); ?>" method="POST"  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <!-- Add form fields for book here -->
                                <div class="mb-3">
                                    <label for="category_id" class="form-label"><?php echo e(__('message.categoryname')); ?></label>
                                    <select class="form-select" id="categoryId" name="categoryId" required>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="title" class="form-label"><?php echo e(__('message.bookname')); ?></label>
                                    <input type="text" class="form-control" id="title" name="title" required>
                                </div>
                                <div class="mb-3">
                                    <label for="author" class="form-label"><?php echo e(__('message.author')); ?></label>
                                    <input type="text" class="form-control" id="author" name="author" required>
                                </div>
                                <div class="mb-3">
                                    <label for="description" class="form-label"><?php echo e(__('message.description')); ?></label>
                                    <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="history" class="form-label"><?php echo e(__('message.history')); ?></label>
                                    <input type="date" class="form-control" id="history" name="history" rows="3" required>
                                </div>
                                <div class="mb-3">
                                    <label for="number_page" class="form-label"><?php echo e(__('message.numberpage')); ?></label>
                                    <input type="number" class="form-control" id="number_page" name="number_page" required>
                                </div>
                                <div class="mb-3">
                                    <label for="price" class="form-label"><?php echo e(__('message.price')); ?></label>
                                    <input type="text" class="form-control" id="price" name="price" required>
                                </div>
                                <div class="mb-3">
                                    <label for="language" class="form-label"><?php echo e(__('message.language')); ?></label>
                                    <input type="text" class="form-control" id="language" name="language" required>
                                </div>
                                <div class="mb-3">
                                    <label for="state" class="form-label"><?php echo e(__('message.state')); ?></label>
                                    <input type="text" class="form-control" id="state" name="state" required>
                                </div>
                                <div class="mb-3">
                                    <label for="image" class="form-label"><?php echo e(__('message.image')); ?></label>
                                    <input type="file" class="form-control" id="image" name="image" required>
                                </div>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('message.save')); ?></button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('message.close')); ?></button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <table class="table-auto" style="width: 100%">
                        <thead>
                            <tr>
                                <th style="text-align: unset"><?php echo e(__('message.number')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.categoryname')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.bookname')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.author')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.description')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.history')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.numberpage')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.price')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.language')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.state')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.image')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->category->name); ?></td>
                                    <td><?php echo e($item->title); ?></td>
                                    <td><?php echo e($item->author); ?></td>
                                    <td><?php echo e($item->description); ?></td>
                                    <td><?php echo e($item->history); ?></td>
                                    <td><?php echo e($item->number_page); ?></td>
                                    <td><?php echo e($item->price); ?></td>
                                    <td><?php echo e($item->language); ?></td>
                                    <td><?php echo e($item->state); ?></td>
                                    <td>
                                        <img src="data:image/jpeg;base64,<?php echo e($item->image); ?>" alt="Image" width="100">
                                    </td>
                                    
                                    <td>
                                        <!-- Edit Button -->
                                        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($item->id); ?>"><?php echo e(__('message.edit')); ?></button>
                                        
                                        <!-- Delete Button -->
                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($item->id); ?>"><?php echo e(__('message.delete')); ?></button>

                                        <!-- Edit Modal -->
                                        <div style="color: #000;" class="modal fade" id="editModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="editModalLabel<?php echo e($item->id); ?>"><?php echo e(__('message.editeform')); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('books.update', $item->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <!-- Add form fields for book here with existing values -->
                                                            <div class="mb-3">
                                                                <label for="category_id" class="form-label"><?php echo e(__('message.categoryname')); ?></label>
                                                                <select class="form-select" id="categoryId" name="categoryId" required>
                                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($category->id); ?>" <?php echo e($item->category_id == $category->id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="title" class="form-label"><?php echo e(__('message.bookname')); ?></label>
                                                                <input type="text" class="form-control" id="title" name="title" value="<?php echo e($item->title); ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="author" class="form-label"><?php echo e(__('message.author')); ?></label>
                                                                <input type="text" class="form-control" id="author" name="author" value="<?php echo e($item->author); ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="description" class="form-label"><?php echo e(__('message.description')); ?></label>
                                                                <textarea class="form-control" id="description" name="description" rows="3" required><?php echo e($item->description); ?></textarea>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="history" class="form-label"><?php echo e(__('message.history')); ?></label>
                                                                <textarea class="form-control" id="history" name="history" rows="3" required><?php echo e($item->history); ?></textarea>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="number_page" class="form-label"><?php echo e(__('message.numberpage')); ?></label>
                                                                <input type="number" class="form-control" id="number_page" name="number_page" value="<?php echo e($item->number_page); ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="price" class="form-label"><?php echo e(__('message.price')); ?></label>
                                                                <input type="text" class="form-control" id="price" name="price" value="<?php echo e($item->price); ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="language" class="form-label"><?php echo e(__('message.language')); ?></label>
                                                                <input type="text" class="form-control" id="language" name="language" value="<?php echo e($item->language); ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="state" class="form-label"><?php echo e(__('message.state')); ?></label>
                                                                <input type="text" class="form-control" id="state" name="state" value="<?php echo e($item->state); ?>" required>
                                                            </div>
                                                            <button type="submit" class="btn btn-warning"><?php echo e(__('message.edit')); ?></button>
                                                        </form>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('message.close')); ?></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Delete Modal -->
                                        <div style="color: #000;" class="modal fade" id="deleteModal<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="deleteModalLabel<?php echo e($item->id); ?>"><?php echo e(__('message.deleteform')); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <?php echo e(__('message.deleteconfirmation')); ?>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <form action="<?php echo e(route('books.destroy', $item->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger"><?php echo e(__('message.delete')); ?></button>
                                                        </form>
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('message.close')); ?></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\prived project\aamna\Library\app-Library\resources\views/booke/index.blade.php ENDPATH**/ ?>