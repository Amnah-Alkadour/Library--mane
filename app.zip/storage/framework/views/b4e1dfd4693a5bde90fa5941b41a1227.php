<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('message.read')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <form method="GET" action="<?php echo e(route('read.index')); ?>">
                        <div class="mb-4">
                            <label for="search" class="form-label"><?php echo e(__('message.searchUser')); ?></label>
                            <input type="text" name="search" id="search" class="form-control" placeholder="<?php echo e(__('message.enterUserName')); ?>" value="<?php echo e(request('search')); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('message.search')); ?></button>
                    </form>
                    <table class="table-auto" style="width: 100%">
                        <thead>
                            <tr>
                                <th style="text-align: unset"><?php echo e(__('message.number')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.userName')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.bookname')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.BookingPeriod')); ?></th>
                                <th style="text-align: unset"><?php echo e(__('message.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $read): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($read->id); ?></td>
                                    <td><?php echo e($read->user->name); ?></td>
                                    <td><?php echo e($read->book->title); ?></td>
                                    <td><?php echo e($read->BookingPeriod); ?></td>
                                    <td>
                                         <!-- Edit Button -->
                                         <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($read->id); ?>"><?php echo e(__('message.edit')); ?></button>
                                        
                                         <!-- Delete Button -->
                                         <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($read->id); ?>"><?php echo e(__('message.delete')); ?></button>
                     
                                         <!-- Edit Modal -->
                                         <div class="modal fade" id="editModal<?php echo e($read->id); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($read->id); ?>" aria-hidden="true">
                                             <div class="modal-dialog">
                                                 <div class="modal-content">
                                                     <div class="modal-header">
                                                         <h5 class="modal-title" id="editModalLabel<?php echo e($read->id); ?>"><?php echo e(__('message.editform')); ?></h5>
                                                         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                     </div>
                                                     <div class="modal-body">
                                                         <form action="<?php echo e(route('reads.update', $read->id)); ?>" method="POST">
                                                             <?php echo csrf_field(); ?>
                                                             <?php echo method_field('PUT'); ?>
                                                             <div class="mb-3">
                                                                <label for="user_id" class="form-label"><?php echo e(__('message.userName')); ?></label>
                                                                <select class="form-select" id="user_id" name="user_id">
                                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == $read->user_id ? 'selected' : ''); ?>>
                                                                            <?php echo e($user->name); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>                                                                
                                                             </div>
                                                             <div class="mb-3">
                                                                 <label for="book_id" class="form-label"><?php echo e(__('message.book_id')); ?></label>
                                                                 <select class="form-select" id="book_id" name="book_id">
                                                                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($book->id); ?>" <?php echo e($book->id == $read->book_id ? 'selected' : ''); ?>>
                                                                            <?php echo e($book->title); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>                                                                
                                                             </div>
                                                             <div class="mb-3">
                                                                 <label for="BookingPeriod" class="form-label"><?php echo e(__('message.BookingPeriod')); ?></label>
                                                                 <input type="date" class="form-control" id="BookingPeriod" name="BookingPeriod" value="<?php echo e($read->BookingPeriod); ?>" required/>
                                                             </div>
                                                             <button type="submit" class="btn btn-warning"><?php echo e(__('message.edit')); ?></button>
                                                         </form>
                                                     </div>
                                                     <div class="modal-footer">
                                                         <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('message.close')); ?></button>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                     
                                         <!-- Delete Modal -->
                                         <div class="modal fade" id="deleteModal<?php echo e($read->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($read->id); ?>" aria-hidden="true">
                                             <div class="modal-dialog">
                                                 <div class="modal-content">
                                                     <div class="modal-header">
                                                         <h5 class="modal-title" id="deleteModalLabel<?php echo e($read->id); ?>"><?php echo e(__('message.deleteform')); ?></h5>
                                                         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                     </div>
                                                     <div class="modal-body">
                                                         <?php echo e(__('message.deleteconfirmation')); ?>

                                                     </div>
                                                     <div class="modal-footer">
                                                         <form action="<?php echo e(route('reads.destroy', $read->id)); ?>" method="POST">
                                                             <?php echo csrf_field(); ?>
                                                             <?php echo method_field('DELETE'); ?>
                                                             <button type="submit" class="btn btn-danger"><?php echo e(__('message.delete')); ?></button>
                                                         </form>
                                                         <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('message.close')); ?></button>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </td>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\prived project\aamna\Library\app-Library\resources\views/read/index.blade.php ENDPATH**/ ?>