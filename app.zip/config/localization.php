<?php

return[
    'locales'=>[
        'ar',
        'en',
    ]
    ];